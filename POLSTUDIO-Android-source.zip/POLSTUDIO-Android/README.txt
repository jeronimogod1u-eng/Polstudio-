POLSTUDIO - proyecto inicial Android para Minecraft Bedrock

Incluye:
- Fondo extraído del archivo MCAddon enviado.
- Música MP3 enviada, en bucle y con botón para silenciar.
- Interfaz propia POLSTUDIO y botón JUGAR.
- Servidor configurado: play.zelixhost.com, puerto 27785.

IMPORTANTE SOBRE JUGAR:
El enlace externo de Bedrock se usa para agregar POLSTUDIO a la lista de servidores. No garantiza entrar directamente al mundo en todas las versiones de Minecraft/Android. El botón intenta abrir Minecraft Bedrock con ese servidor.

Compilación desde celular:
1. Abre este proyecto en una aplicación/entorno Android que soporte proyectos Gradle Kotlin (por ejemplo AndroidIDE).
2. Sincroniza Gradle con internet y compila la variante debug.
3. Instala el APK generado en app/build/outputs/apk/debug/.

Este paquete es el código fuente inicial, NO es todavía un APK compilado. Para compilar se necesita Android SDK/Gradle en el dispositivo o en un PC.
