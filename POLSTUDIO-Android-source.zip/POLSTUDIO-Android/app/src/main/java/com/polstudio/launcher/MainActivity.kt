package com.polstudio.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private lateinit var musicButton: Button
    private var musicEnabled = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = FrameLayout(this)
        root.background = android.graphics.drawable.BitmapDrawable(resources,
            android.graphics.BitmapFactory.decodeResource(resources, R.drawable.polstudio_background)).also {
            it.gravity = Gravity.CENTER
        }
        root.foreground = android.graphics.drawable.ColorDrawable(0x55000000)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }
        val title = TextView(this).apply {
            text = "POLSTUDIO"
            textSize = 38f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
            setShadowLayer(10f, 2f, 3f, Color.BLACK)
        }
        val subtitle = TextView(this).apply {
            text = "BEDROCK CUSTOM LAUNCHER"
            textSize = 13f
            letterSpacing = 0.18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 42)
        }
        val play = Button(this).apply {
            text = "▶  JUGAR"
            textSize = 20f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(0xFF258B45.toInt())
            setOnClickListener { openBedrockServer() }
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 62).apply {
            setMargins(12, 0, 12, 18)
        }
        val server = TextView(this).apply {
            text = "MINECRAFT BEDROCK"
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        musicButton = Button(this).apply {
            text = "♫  Música: ACTIVADA"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(0xAA202733.toInt())
            setOnClickListener { toggleMusic() }
        }
        content.addView(title)
        content.addView(subtitle)
        content.addView(play, params)
        content.addView(server)
        content.addView(musicButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 52).apply { topMargin = 24 })
        root.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        startMusic()
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = 18f
    }

    private fun startMusic() {
        if (!musicEnabled) return
        if (player == null) player = MediaPlayer.create(this, R.raw.background_music)?.apply {
            isLooping = true
            setVolume(0.65f, 0.65f)
        }
        player?.start()
    }

    private fun toggleMusic() {
        musicEnabled = !musicEnabled
        if (musicEnabled) {
            startMusic()
            musicButton.text = "♫  Música: ACTIVADA"
        } else {
            player?.pause()
            musicButton.text = "♫  Música: SILENCIADA"
        }
    }

    private fun openBedrockServer() {
        // Bedrock's external-server URI adds the server to the server list.
        // Android/Bedrock does not provide a dependable public URI for instant joining on every version.
        val uri = Uri.parse("minecraft://?addExternalServer=POLSTUDIO|play.zelixhost.com:27785")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            Toast.makeText(this, "Instala Minecraft Bedrock para continuar.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
